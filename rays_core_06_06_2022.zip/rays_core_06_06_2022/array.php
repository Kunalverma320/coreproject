<?php

//$a[0]=10;
//$a[1]=2;
//$a[2]=40;
//$a[3]=6;
//$a[4]=70;

//$a=array(10,20,30,40,50);
//print_r($a);

//for($i=0;$i<count($b);$i++)
//{
//    echo $b[$i]."<br>";
//}

//$b=array("101"=>'A',"102"=>'B',"naveen"=>"mandal");
//
//print_r($b);
//echo "<br>";
//foreach ($b as $key=>$value) 
//    {
//            echo $key."=".$value;
//            echo "<br>";
//    }
//

$c=array(10,"101"=>'A',40,"105"=>'B',500,"hi"=>"bye");

//print_r($c);

foreach ($c as $key=>$value) 
    {
            echo $key."=".$value;
            echo "<br>";
    }






?>

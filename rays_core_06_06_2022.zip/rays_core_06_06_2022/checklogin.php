    <?php

    $uname = $_POST['username'];
    $password = $_POST['password'];
    include './function.php';

    $myconn = dbConnect();
    
    
    $sql="SELECT * FROM udata WHERE uname='$uname' AND pwd='$password'";
    
    $rs=mysqli_query($myconn, $sql);
    
    if($row= mysqli_fetch_assoc($rs))
    {
        
        session_start();
        
        // set the session data
        $_SESSION['sess_uid']=$row['uid'];
        $_SESSION['sess_uname']=$row['uname'];
//        $_SESSION['sess_uname']=$uname;
        
        
        
        header("Location:userhome.php");
    }
    else
    {
        header("Location:userlogin.php?invalid=yes");
    }
    
    
    ?>
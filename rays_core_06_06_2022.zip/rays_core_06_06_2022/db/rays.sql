-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.28 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for rays
DROP DATABASE IF EXISTS `rays`;
CREATE DATABASE IF NOT EXISTS `rays` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rays`;

-- Dumping structure for table rays.product
DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  `pdescr` text COLLATE utf8mb4_general_ci,
  `ptype` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table rays.product: ~4 rows (approximately)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`pid`, `pname`, `price`, `pdescr`, `ptype`) VALUES
	(1, 'Tomato', 200, 'veggies', 'Furniture'),
	(2, 'Bringle', 10, 'veggies', 'Furniture');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

-- Dumping structure for table rays.singer
DROP TABLE IF EXISTS `singer`;
CREATE TABLE IF NOT EXISTS `singer` (
  `singer_id` int NOT NULL AUTO_INCREMENT,
  `singer_name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`singer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table rays.singer: ~6 rows (approximately)
/*!40000 ALTER TABLE `singer` DISABLE KEYS */;
INSERT INTO `singer` (`singer_id`, `singer_name`) VALUES
	(1, 'Sonu Nigam'),
	(2, 'KK'),
	(3, 'Atif Aslam'),
	(4, 'Monali Thakur'),
	(5, 'Shreya Ghosal'),
	(6, 'Harshdeep'),
	(7, 'Arijit Singh');
/*!40000 ALTER TABLE `singer` ENABLE KEYS */;

-- Dumping structure for table rays.songs
DROP TABLE IF EXISTS `songs`;
CREATE TABLE IF NOT EXISTS `songs` (
  `song_id` int NOT NULL AUTO_INCREMENT,
  `song_name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fk_singer_id` int DEFAULT NULL,
  PRIMARY KEY (`song_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table rays.songs: ~2 rows (approximately)
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
INSERT INTO `songs` (`song_id`, `song_name`, `fk_singer_id`) VALUES
	(1, 'a.mp3', 1),
	(2, 'b.mp3', 5),
	(3, 'c.mp3', 7);
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;

-- Dumping structure for table rays.student
DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `rno` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mobile` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Raipur' COMMENT 'only cg cities are allowed',
  `percentage` varchar(6) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table rays.student: ~6 rows (approximately)
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`rno`, `sname`, `mobile`, `city`, `percentage`) VALUES
	(1, 'Naveen', '7415303000', 'Raipur', '67'),
	(2, 'Kunal', '7415303001', 'bhilai', '87'),
	(3, 'Geetu', '7415303002', 'bhilai', '78'),
	(4, 'Kanchan', '9999999998', 'Raipur', '76'),
	(5, 'ekta', '9898989899', 'Dhamtari', '98.6'),
	(7, 'ekta', '9898989890', 'Dhamtari', '98.6');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;

-- Dumping structure for table rays.udata
DROP TABLE IF EXISTS `udata`;
CREATE TABLE IF NOT EXISTS `udata` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pwd` varchar(8) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mobile` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `full_name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'avatar.png',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table rays.udata: ~2 rows (approximately)
/*!40000 ALTER TABLE `udata` DISABLE KEYS */;
INSERT INTO `udata` (`uid`, `uname`, `pwd`, `mobile`, `full_name`, `image_name`) VALUES
	(1, 'admin', '12345', '7415303000', 'Naveen Mandal', 'Praveen.jpg'),
	(2, 'user', '12345', '8103374257', 'Kunal Verma', 'avatar.png');
/*!40000 ALTER TABLE `udata` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

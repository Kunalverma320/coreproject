<?php


$my_pid=$_REQUEST['id'];

include './function.php';
$myconn= dbConnect();
$sql_delete="DELETE FROM product WHERE pid='$my_pid'";
mysqli_query($myconn, $sql_delete);

header("location:retrieve_2.php?del=yes");

?>

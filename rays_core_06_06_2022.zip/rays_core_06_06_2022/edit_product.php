<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') 
    {
    $pid = $_REQUEST['my_pid'];
    $pname = $_REQUEST['my_pname'];
    $price = $_REQUEST['my_price'];
    include './function.php';
    $myconn = dbConnect();
    $sql = "UPDATE product SET pname='$pname',price='$price' WHERE pid='$pid'";
    mysqli_query($myconn, $sql);

    if (mysqli_affected_rows($myconn) > 0) {
        header("location:retrieve_2.php?upd=yes");
    } else {
        header("location:retrieve_2.php?upderror=yes");
    }
}
?>


<!doctype html>
<html>

    <head>
        <title>Edit</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>
<?php
include 'menu.php';
?>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2 style="text-align:center">Edit Product</h2>
<?php
$pid = $_REQUEST['id'];
//                    echo $pid;
include './function.php';
$myconn = dbConnect();
$sql_product = "SELECT pid,pname,price FROM product WHERE pid='$pid'";
$rs = mysqli_query($myconn, $sql_product);
$row = mysqli_fetch_assoc($rs);
//                    print_r($row);
?>
                    <form action="" method="POST">

                        <input type="hidden" value="<?= $row['pid'] ?>" name="my_pid">
                        Name
                        <input type="text" name="my_pname" class="form-control b" value="<?= $row['pname'] ?>" placeholder="Enter Name Here">
                        Price
                        <input type="number" name="my_price"  class="form-control b" value="<?= $row['price'] ?>" placeholder="Enter Price Here">
                        <input type="submit"  class="btn btn-primary b">
                    </form>



                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>
</html>
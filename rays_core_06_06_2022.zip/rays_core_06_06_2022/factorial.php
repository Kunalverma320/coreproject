
<!doctype html>
<html>

    <head>
        <title>Form Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>
        <?php
        include 'menu.php';
        ?>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">

                    <h2 style="text-align:center">factorial</h2>
                    <form method="POST">
                        <input type="number" name="n" class="form-control" placeholder="Enter Any Number" autofocus required>

                        <input type="submit" class="btn btn-primary">
                    </form>

                    <center>
                        <h2 style="color:#ffffff">
                        <?php
                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                            $n = $_POST['n'];
                            $fact = 1;
                            while ($n != 0) {
                                $fact = $fact * $n;
                                $n = $n - 1;
                            }
                            echo "The Factorial is:" . $fact;
                        }
                        ?>
                        </h2>
                    </center>
                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>

</html>
<?php
$conn = mysqli_connect("localhost", "chips", "nmdl", "rays");
$sql = "SELECT * FROM product ";
$rs = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($rs);

print_r($row);

?>


<!--<p align="center" style="font-size: 20px">
    <?php
    
    echo $row['pname'];
    
    ?>
</p>-->
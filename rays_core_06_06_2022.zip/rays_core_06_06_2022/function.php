<?php

function test() {   // function definition
    echo "Hello world";
}

function add_two_numbers($x, $y) {
    $z = $x + $y;
    return $z;
}

function dbConnect() {
    $conn = mysqli_connect("localhost", "root", "", "rays");

    if (!$conn) {
        echo "Not Connected...!";
    }
    return $conn;
}

?>
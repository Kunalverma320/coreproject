<?php

$n=100;

function test()
{
    
    $n=1000;
    echo "Global wala:".$GLOBALS['n'];
    echo "<br>";
    echo "Local wala:".$n;
    
}


test();


?>

<h2>

    <?php
    $n = 100;

    $a = 10.5;  // float double

    $s1 = "Hello World";
    $s2 = 'Bye Bye';

    echo $s1 . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $s2;
    echo "<br>";
    print($a);
    ?>

    <?php
    
    include './function.php';
//    test();
    
    $result=add_two_numbers(100, 200);
    echo "The Sum is:".$result;
    
    ?>


<h2>
<?php
// Step 1: Connect the DB

$conn=mysqli_connect("localhost","chips","nmdl","rays");

$my_name='ekta';
$my_mobile='9898989890';
$my_city='Dhamtari';
$percent='98.6';

// Step 2 -  Store the query
$query="INSERT INTO student(sname,mobile,city,percentage) VALUES('$my_name','$my_mobile','$my_city','$percent')";


// Step 3- Execute the query

mysqli_query($conn, $query);

if(mysqli_affected_rows($conn)>0)
{
    echo "Data Saved Successfully...!!!!!!!!!";
}


?>

<h2>
<?php


//print_r($_REQUEST);

$a=$_POST['A'];
$b=$_POST['B'];


$c=$a+$b;


echo "The Sum is:".$c;


?>
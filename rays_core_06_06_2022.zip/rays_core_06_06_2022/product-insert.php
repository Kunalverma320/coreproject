<?php

//print_r($_POST);

$mypname=$_POST['pname'];
$myprice=$_POST['price'];
$mypdescr=$_POST['pdescr'];
$myptype=$_POST['ptype'];

include './function.php';
$myconn=db_connect();


$query="INSERT INTO product(pname,price,pdescr,ptype) VALUES('$mypname','$myprice','$mypdescr','$myptype')";

mysqli_query($myconn, $query);

header("Location:register.php?success=abc");

?>

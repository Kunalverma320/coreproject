-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 11:09 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rays`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `price` int(11) NOT NULL DEFAULT 0,
  `pdescr` text DEFAULT NULL,
  `ptype` varchar(20) DEFAULT NULL,
  `photo` varchar(100) NOT NULL,
  `mrp` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `price`, `pdescr`, `ptype`, `photo`, `mrp`) VALUES
(7, 'skybag', 600, 'bag', 'bag', 'a3.png', 1000),
(13, 'skybag2', 525, 'bag2', 'bag', 'banner-img.png', 555),
(14, 'cartoon', 525, 'bag2', 'bag', 'f3.png', 555),
(15, 'gift', 525, 'bag2', 'bag', 'a3.png', 555),
(16, 'gift', 525, 'bag2', 'bag', 'a3.png', 555),
(17, 'aristocart', 1500, 'bag', 'bag', 'photo6142927548800151358 (1) (1).jpg', 3300),
(18, 'aristocart', 1500, 'bag', 'bag', 'photo6142927548800151358 (1) (1).jpg', 3300),
(19, 'aristocart', 1500, 'bag', 'bag', 'photo6142927548800151358 (1) (1).jpg', 3300),
(20, 'aristocart', 1500, 'bag', 'bag', 'photo6142927548800151358 (1) (1).jpg', 3300),
(21, 'aristocart', 1500, 'bag', 'bag', 'photo6142927548800151358 (1) (1).jpg', 3300);

-- --------------------------------------------------------

--
-- Table structure for table `singer`
--

CREATE TABLE `singer` (
  `singer_id` int(11) NOT NULL,
  `singer_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `singer`
--

INSERT INTO `singer` (`singer_id`, `singer_name`) VALUES
(1, 'Sonu Nigam'),
(2, 'KK'),
(3, 'Atif Aslam'),
(4, 'Monali Thakur'),
(5, 'Shreya Ghosal'),
(6, 'Harshdeep'),
(7, 'Arijit Singh');

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `song_id` int(11) NOT NULL,
  `song_name` varchar(100) DEFAULT NULL,
  `fk_singer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `songs`
--

INSERT INTO `songs` (`song_id`, `song_name`, `fk_singer_id`) VALUES
(1, 'a.mp3', 1),
(2, 'b.mp3', 5),
(3, 'c.mp3', 7);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `rno` int(11) NOT NULL,
  `sname` varchar(25) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `city` varchar(20) DEFAULT 'Raipur' COMMENT 'only cg cities are allowed',
  `percentage` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rno`, `sname`, `mobile`, `city`, `percentage`) VALUES
(1, 'Naveen', '7415303000', 'Raipur', '67'),
(2, 'Kunal', '7415303001', 'bhilai', '87'),
(3, 'Geetu', '7415303002', 'bhilai', '78'),
(4, 'Kanchan', '9999999998', 'Raipur', '76'),
(5, 'ekta', '9898989899', 'Dhamtari', '98.6'),
(7, 'ekta', '9898989890', 'Dhamtari', '98.6');

-- --------------------------------------------------------

--
-- Table structure for table `udata`
--

CREATE TABLE `udata` (
  `uid` int(11) NOT NULL,
  `uname` varchar(20) DEFAULT NULL,
  `pwd` varchar(8) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `full_name` varchar(50) DEFAULT NULL,
  `image_name` varchar(50) DEFAULT 'avatar.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `udata`
--

INSERT INTO `udata` (`uid`, `uname`, `pwd`, `mobile`, `full_name`, `image_name`) VALUES
(1, 'admin', '12345', '7415303000', 'Naveen Mandal', 'Praveen.jpg'),
(2, 'user', '12345', '8103374257', 'Kunal Verma', 'avatar.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `singer`
--
ALTER TABLE `singer`
  ADD PRIMARY KEY (`singer_id`);

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`song_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`rno`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `udata`
--
ALTER TABLE `udata`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `singer`
--
ALTER TABLE `singer`
  MODIFY `singer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `songs`
--
ALTER TABLE `songs`
  MODIFY `song_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `rno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `udata`
--
ALTER TABLE `udata`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

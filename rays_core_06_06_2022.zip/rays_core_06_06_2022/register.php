<!doctype html>
<html>

    <head>
        <title>First Page BS</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>
        <?php
        include 'menu.php';
        
        ?>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2 style="text-align:center">Product Entry</h2>

                    <?php
                    if (isset($_REQUEST['success'])) {
                        ?>

                        <div class="alert alert-success">
                            <strong>Success!</strong> Data Save ho gyaaa hai dekh le.
                        </div>

                        <?php
                    }
                    ?>

                    <form action="product-insert.php" method="POST">
                        <input type="text" class="form-control" name="pname" placeholder="Enter Product Name" autofocus>
                        <input type="number" class="form-control m" name="price"  placeholder="Enter Product Price">
                        <input type="text" class="form-control m" name="pdescr"  placeholder="Enter Product Description">
                        <select class="form-control m b" name="ptype">
                            <option>Vegetable</option>
                            <option>Fruits</option>
                            <option>Furniture</option>
                        </select>
                        <input type="submit" class="btn btn-primary">
                        <input type="reset" class="btn btn-danger">
                    </form>
                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>

</html>
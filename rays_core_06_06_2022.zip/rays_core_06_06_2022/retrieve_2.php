<!doctype html>
<html>

    <head>
        <title>File Upload</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>
        <?php
        include 'menu.php';
        ?>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2 style="text-align:center">All Products  </h2>

                    <?php
                    $conn = mysqli_connect("localhost", "chips", "nmdl", "rays");
                    $sql = "SELECT * FROM product ";
                    $rs = mysqli_query($conn, $sql);
                    ?>
                    <table class="table table-responsive table-bordered">
                        <tr>
                            <th>Product ID</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Description</th>
                            <th>Action</th>

                        </tr>
                        <?php
                        $row_number = 1;
                        while ($row = mysqli_fetch_assoc($rs)) {
                            ?>
                            <tr>
                                <td><?php echo $row['pid'];?></td>
                                <td><?= $row['pname'] ?></td>
                                <td><?= $row['price'] ?></td>
                                <td><?= $row['pdescr'] ?></td>
                                <td>
                                    <a href="edit_product.php?id=<?=$row['pid']?>">
                                        <img src="images/edit.png" width="23px" height="23px">
                                    </a>
                                     <a href="delete_product.php?id=<?=$row['pid']?>">
                                        <img src="images/delete.png" width="23px" height="23px">
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>
</html>
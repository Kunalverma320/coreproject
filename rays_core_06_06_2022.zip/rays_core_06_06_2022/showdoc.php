<?php
session_start();
$uid = $_SESSION['sess_uid'];
if (!isset($_SESSION['sess_uid'])) {
    header("Location:userlogin.php?direct=yes");
}
?>
<!doctype html>
<html>

    <head>
        <title>Form Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>


        <?php
        include 'menu.php';
        ?>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2">
                   
                </div>
                <div class="col-md-8">
                    <h2>
                        Welcome <?= $_SESSION['sess_uname'] ?>
                    </h2>

                    <h3 align="center">

<?php
$doc = $_REQUEST['doc'];
?>

                        <iframe src="uploads/doc/<?= $doc ?>" width="80%" height="500px"></iframe>


                    </h3>

                </div>
                <div class="col-md-2">
                </div>
            </div>
        </div>
    </body>

</html>


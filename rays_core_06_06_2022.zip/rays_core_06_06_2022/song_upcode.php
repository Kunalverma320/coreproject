<?php

$sid=$_POST['singer'];
$fname=$_FILES['songfile']['name'];
$ftemp=$_FILES['songfile']['tmp_name'];
$ftype=$_FILES['songfile']['type'];




if(($ftype=='audio/mp3')  || ($ftype=='audio/mpeg'))
{
    move_uploaded_file($ftemp, "uploads/audio/".$fname);
    include './function.php';
    $myconn= dbConnect();
    $sql_save="INSERT INTO songs(song_name, fk_singer_id) VALUES('$fname','$sid')";
    mysqli_query($myconn, $sql_save);
    header("Location:songs.php");
}
else
{
    header("Location:song_upload.php?inv=yes");
}





<!doctype html>
<html>

    <head>
        <title>File Upload</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>
        <?php
        include 'menu.php';
        ?>


        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2 style="text-align:center">Song Upload</h2>

                    <form action="song_upcode.php" method="POST" enctype="multipart/form-data">

                        <select name="singer" class="form-control b">

                            <?php
                            include './function.php';
                            $myconn = dbConnect();
                            $sql_singer = "SELECT * FROM singer";
                            $rs = mysqli_query($myconn, $sql_singer);
                            while ($row = mysqli_fetch_assoc($rs)) {
                                ?>
                                <option value="<?= $row['singer_id'] ?>"><?= $row['singer_name'] ?></option>
                                <?php
                            }
                            ?>

                        </select>
                        <input type="file" name="songfile" class="form-control b">
                        <input type="submit" class="btn btn-primary">
                    </form>
                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>

</html>     
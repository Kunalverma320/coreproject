<?php
include './function.php';
$mycon = dbConnect();

$sql_songs = "SELECT songs.song_name,singer.singer_name FROM songs INNER JOIN singer ON songs.fk_singer_id=singer.singer_id";

$rs = mysqli_query($mycon, $sql_songs);

while ($row = mysqli_fetch_assoc($rs)) {
    ?>

<p><?=$row['singer_name']?>
    <audio controls>
        <source src="audio/<?= $row['song_name'] ?>" type="audio/mpeg">
    </audio>
</p>
    <?php
}

<?php

$num=10;

echo $num;
?>
<!doctype html>
<html>

    <head>
        <title>Form Example</title>
       
    </head>
    <body>
        Hello world
    </body>

</html>
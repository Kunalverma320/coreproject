<?php

$fname = $_FILES['image']['name'];
$ftype = $_FILES['image']['type'];
$fsize = $_FILES['image']['size'];
$ftemp_name = $_FILES['image']['tmp_name'];
$ferror = $_FILES['image']['error'];


session_start();
$uid = $_SESSION['sess_uid'];

if ((($ftype == 'image/jpeg') || ($ftype == 'image/png')) && ($fsize < 2097152)) {
    if ($ferror > 0) {
        echo "Some Erro Occurred...!";
    } else {
        move_uploaded_file($ftemp_name, "uploads/images/" . $fname);

        // update query

        $sql_update = "UPDATE udata SET image_name='$fname' WHERE uid='$uid'";
        include './function.php';
        $myconn = dbConnect();
        mysqli_query($myconn, $sql_update);
        header("location:userhome.php");
    }
} else 
{
    header("location:upload.php?inv=yes");
}
?>

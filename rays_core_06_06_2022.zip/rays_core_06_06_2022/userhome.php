<?php
session_start();
$uid=$_SESSION['sess_uid'];
if (!isset($_SESSION['sess_uid'])) {
    header("Location:userlogin.php?direct=yes");
}
?>
<!doctype html>
<html>

    <head>
        <title>Form Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>


        <?php
        include 'menu.php';
        ?>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <?php
                    $sql_data="SELECT image_name,doc_name FROM udata WHERE uid='$uid'";
                    
                    include './function.php';
                    $myconn=dbConnect();
                    
                    $rs=mysqli_query($myconn, $sql_data);
                    $row=mysqli_fetch_assoc($rs);
//                    echo $row['image_name'];
                    
                    
                    
                    ?>
                    <img src="uploads/images/<?=$row['image_name']?>" class="img-responsive">
                    <a href="upload.php">
                        
                        <?php
                        
                        if($row['image_name']=='avatar.png')
                        {
                            echo "Upload Photo";
                        }
                        else
                        {
                            echo "Change Photo";
                        }
                        
                        ?>
                    </a>
                    <br>
                    <a href="showdoc.php?doc=<?=$row['doc_name']?>">View Resume</a>
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2>
                        Welcome <?= $_SESSION['sess_uname'] ?>
                    </h2>

                    <h3 align="center">

                        <a href="logout.php">Sign Out</a>

                    </h3>

                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>

</html>
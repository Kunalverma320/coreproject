<!doctype html>
<html>

    <head>
        <title>Form Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="X-UA-Compatible">
        <style>
            .m
            {
                margin-top: 10px;
            }
            .b
            {
                margin-bottom: 10px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

    </head>

    <body>


        <?php
        include 'menu.php';
        ?>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
                <div class="col-md-6" style="background-color: #aabbcc;border-radius:20px">
                    <h2 style="text-align:center">User Login</h2>
<?php
if(isset($_REQUEST['invalid'])) {
    ?>
                        <div class="alert alert-danger">
                            <strong>Oops!</strong> Invalid Login ID or Password
                        </div>
    <?php
}

if(isset($_REQUEST['log'])) {
    ?>
                        <div class="alert alert-success">
                            <strong>Success!</strong> Successfully Logged Out
                        </div>
    <?php
}
if(isset($_REQUEST['direct'])) {
    ?>
                        <div class="alert alert-info">
                            <strong>Error!</strong> Not Authorized to view the page plz login first
                        </div>
    <?php
}
?>
                    <form action="checklogin.php" method="POST">
                        <input type="text" name="username" class="form-control" placeholder="Enter User Name" autofocus required>
                        <input type="password" name="password" class="form-control m"  placeholder="Enter Password" required>
                        <input type="submit" class="btn btn-primary">
                    </form>
                </div>
                <div class="col-md-3">
                    <img src="images/tomato.jpg" class="img-responsive">
                </div>
            </div>
        </div>
    </body>

</html>
<?php

static $a=500;
$a++;
function update_data()
{
    $a=200;
    static $n=100;
    $n++;
    echo "local:".$a."<br>";
    echo "static".$n."<br>";
}

update_data();
update_data();
update_data();
update_data();
update_data();

echo $a;
?>
